package com.example.flutter_nav_data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
